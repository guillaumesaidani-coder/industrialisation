# Laboratoire v1 — petits défauts, résolution et métriques vision

Version : `2026-08-23` · Python `3.13` · bibliothèque standard uniquement.

Ce laboratoire synthétique rend observable un piège signalé par la cohorte de juin : une moyenne globale peut diluer un petit défaut. Il compare, sur deux canevas, la MSE globale, une SSIM globale **explicitement simplifiée**, une carte d'erreur et un score local nommé exactement **proxy pédagogique inspiré de PatchCore**.

> Ce laboratoire n'implémente jamais PatchCore. PatchCore réel utilise des **embeddings deep** et un **coreset** avant la comparaison locale. Il doit être évalué sur le même protocole (données/split, résolution, classes, seed et budget mesuré) ; aucun vainqueur n'est présumé ici.

## Objectifs apprenant

À la fin, l'apprenant sait :

1. expliquer pourquoi une MSE globale peut masquer un défaut localisé ;
2. distinguer une SSIM globale simplifiée d'une SSIM locale validée ;
3. relier la résolution au protocole de mesure, sans conclure « plus grand = meilleur » ;
4. lire une carte d'erreur et un score local par patches ;
5. conserver une preuve JSON avec durée et pic mémoire observés, sans inventer de seuil ni de coût.

Le défaut synthétique garde le **même nombre de pixels** quand le canevas grandit. C'est un contrôle volontaire de dilution en espace pixel, pas la simulation d'un défaut physique invariant. Les résolutions par défaut `32` et `128` sont des paramètres pédagogiques synthétiques, pas des valeurs métier.

## Contenu

- `lab.py` : génération PNG grayscale, métriques, télémétrie et preuve JSON ;
- `tests/test_lab.py` : tests d'invariants relationnels, sans seuil de performance ;
- `pyproject.toml` : contrat Python `>=3.13,<3.14`, aucune dépendance ;
- `uv.lock` : verrou hors ligne, SHA-256 observé `B171CA2CF7ED90D64E81CB0AE734593BACE5F7D8ADC70C95D8CB8193768854AE` ;
- `README.md` : consigne, questions, FAQ, diagnostic et plans B.

Aucun réseau, GPU, Docker, Torch, package Python ou donnée externe n'est utilisé.

## Démarrage PowerShell / Windows

Depuis ce dossier :

```powershell
Set-Location "C:\CHEMIN\VERS\vision_metrics_lab_v1_20260823"
uv sync --frozen --offline
if ($LASTEXITCODE -ne 0) { throw "Synchronisation verrouillée impossible (code $LASTEXITCODE)" }
uv run python .\lab.py --output .\sortie_apprenant --resolutions 32 128 --defect-size-px 2 --patch-size-px 4
if ($LASTEXITCODE -ne 0) { throw "Le laboratoire a échoué (code $LASTEXITCODE)" }
```

Le dossier de sortie doit être nouveau ou vide : le script refuse d'écraser une preuve existante. Résultat attendu :

- `sortie_apprenant/preuve.json` ;
- pour chaque résolution, `reference.png`, `avec_defaut.png`, `carte_erreur.png` ;
- `RESULTAT=PASS` dans la console si les invariants relationnels sont vrais.

Lire la preuve sans outil supplémentaire :

```powershell
$preuve = Get-Content .\sortie_apprenant\preuve.json -Raw | ConvertFrom-Json
$preuve.experiences | ForEach-Object {
    [pscustomobject]@{
        Resolution = $_.resolution.largeur_px
        MSEGlobale = $_.metriques_globales.mse
        SSIMGlobaleSimplifiee = $_.metriques_globales.ssim_globale_simplifiee
        ProxyLocalMaxMSE = $_.score_local.score_local_max_mse
    }
} | Format-Table
$preuve.telemetrie_execution | Format-List
```

## Travail apprenant

1. Ouvrir les trois PNG de chaque résolution. Où se trouve le signal dans la carte d'erreur ?
2. Classer les deux MSE globales, puis les deux SSIM globales simplifiées. Qu'est-ce qui change alors que le défaut garde taille et contraste fixes en pixels ?
3. Comparer la MSE globale et le score local maximal de chaque résolution. Pourquoi le score local conserve-t-il le signal ?
4. Expliquer pourquoi cette expérience ne permet pas d'affirmer qu'une résolution élevée améliore un modèle industriel.
5. Noter la durée et le pic mémoire du run. Ne pas en déduire un coût, un SLA ou une capacité : un seul run synthétique n'est pas un benchmark.
6. Proposer un protocole équitable pour comparer un modèle réel et PatchCore réel.

### Preuve de réussite

La preuve est recevable si :

- les six PNG sont lisibles et le JSON référence leur SHA-256 ;
- les trois invariants relationnels du JSON valent `true` ;
- l'apprenant distingue explicitement le proxy local de PatchCore réel ;
- l'interprétation mentionne le contrôle « défaut fixe en pixels » et n'invente aucun seuil de décision.

## Tester le laboratoire

```powershell
$env:PYTHONDONTWRITEBYTECODE = "1"
uv sync --frozen --offline
if ($LASTEXITCODE -ne 0) { throw "Synchronisation verrouillée impossible (code $LASTEXITCODE)" }
uv run python -m unittest discover -s .\tests -p "test_*.py" -v
if ($LASTEXITCODE -ne 0) { throw "Tests en échec (code $LASTEXITCODE)" }
```

Les tests vérifient seulement des relations (par exemple MSE petit canevas `>` MSE grand canevas), la déterminisme des métriques/PNG et l'intégrité structurelle des sorties. Ils n'imposent aucun seuil de qualité, de temps ou de mémoire.

## FAQ

**Est-ce la vraie SSIM ?**  
Non. La formule utilise une seule fenêtre couvrant toute l'image et des variances population. Elle est volontairement lisible, mais ne remplace pas une implémentation locale/multi-fenêtres validée.

**Le proxy prouve-t-il que PatchCore gagne ?**  
Non. C'est un **proxy pédagogique inspiré de PatchCore**, calculé comme le maximum des MSE de patches. PatchCore réel utilise embeddings deep et coreset ; il faut le mesurer sur le même protocole avant toute conclusion.

**Une résolution plus élevée est-elle toujours meilleure ?**  
Non. Ici, le canevas grandit mais le défaut reste fixe en pixels, ce qui étudie la dilution. Un test métier doit préserver ce qui représente la même réalité physique et mesurer qualité, durée et mémoire.

**Pourquoi ne pas définir un seuil d'anomalie ?**  
Aucune distribution de validation métier n'est fournie. Un seuil serait inventé. Le laboratoire teste donc des invariants relationnels uniquement.

**Les nombres de durée et mémoire sont-ils reproductibles ?**  
Non au bit près : ils dépendent de la machine et de la charge. Les images, métriques et SHA-256 le sont ; la télémétrie est volontairement exclue du test de déterminisme.

## Diagnostic

| Symptôme | Cause probable | Action PowerShell |
|---|---|---|
| `Python 3.13 requis` | Mauvais interpréteur | `uv run python --version` puis vérifier `uv.lock` et `requires-python`. |
| `dossier de sortie n'est pas vide` | Une preuve existe déjà | Choisir un nouveau nom, par exemple `--output .\sortie_02` ; ne rien supprimer automatiquement. |
| `résolution doit être divisible` | Patches non pavables | Choisir des résolutions multiples de `--patch-size-px`. |
| `PermissionError` | Dossier non inscriptible | Utiliser `--output (Join-Path $env:TEMP "vision_lab_preuve")` avec un nom neuf. |
| PNG non prévisualisé | Visionneuse indisponible | Vérifier les SHA-256 et `pixels_non_nuls` dans `preuve.json`; le calcul reste auditable. |
| Durée/mémoire différente | Machine ou charge différente | Consigner la valeur observée ; ne pas remplacer par une valeur attendue inventée. |

## Plans B

- **Hors ligne :** c'est le chemin nominal ; la stdlib suffit et aucune requête réseau n'est émise.
- **Sans GPU/Torch :** c'est le chemin nominal ; aucun framework ML n'est importé.
- **Sans Docker :** c'est le chemin nominal ; lancer directement Python 3.13.
- **Sans droit d'écriture dans le dossier de cours :** écrire vers un nouveau sous-dossier de `$env:TEMP`, puis conserver `preuve.json` et les PNG comme pièces de travail.
- **Python 3.13 indisponible et installation interdite :** faire l'analyse relationnelle à partir du code et des formules, marquer l'exécution `BLOCKED` et ne jamais présenter de durée, mémoire ou métrique comme mesurée localement.
- **Exécution impossible mais lecture autorisée :** conserver le diagnostic complet et demander au formateur la référence datée. La décrire comme un **exemple fourni**, jamais comme une exécution du poste apprenant.

## Limites à dire à voix haute

« Cette expérience prouve un mécanisme de dilution sur des images synthétiques. Elle ne constitue ni un benchmark de modèle, ni une implémentation de PatchCore, ni un calibrage de seuil industriel. Toute comparaison réelle garde le même protocole et publie ses preuves mesurées. »
