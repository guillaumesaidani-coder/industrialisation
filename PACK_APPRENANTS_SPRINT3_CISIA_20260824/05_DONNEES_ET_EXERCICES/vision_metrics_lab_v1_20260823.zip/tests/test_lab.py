from __future__ import annotations

import json
import struct
import sys
import tempfile
import unittest
from pathlib import Path


LAB_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(LAB_DIR))

from lab import (  # noqa: E402
    LabConfig,
    PNG_SIGNATURE,
    PATCH_PROXY_NAME,
    run_lab,
    simplified_global_ssim,
)


class VisionMetricsLabTests(unittest.TestCase):
    def setUp(self) -> None:
        self.assertEqual((3, 13), sys.version_info[:2], "Les tests exigent Python 3.13.")
        self.config = LabConfig()

    def test_relational_invariants_not_numeric_thresholds(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            proof = run_lab(self.config, Path(temporary) / "run")

        low, high = proof["experiences"]
        self.assertGreater(
            low["metriques_globales"]["mse"], high["metriques_globales"]["mse"]
        )
        self.assertLess(
            low["metriques_globales"]["ssim_globale_simplifiee"],
            high["metriques_globales"]["ssim_globale_simplifiee"],
        )
        self.assertEqual(
            low["score_local"]["score_local_max_mse"],
            high["score_local"]["score_local_max_mse"],
        )
        for experiment in (low, high):
            self.assertEqual(PATCH_PROXY_NAME, experiment["score_local"]["nom"])
            self.assertGreater(
                experiment["score_local"]["score_local_max_mse"],
                experiment["metriques_globales"]["mse"],
            )
            self.assertEqual(
                experiment["defaut"]["nombre_pixels"],
                experiment["carte_erreur"]["pixels_non_nuls"],
            )
        self.assertTrue(all(proof["invariants_relationnels_observes"].values()))

    def test_metrics_and_pngs_are_deterministic_telemetry_excluded(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            first = run_lab(self.config, root / "first")
            second = run_lab(self.config, root / "second")

        self.assertEqual(first["protocole"], second["protocole"])
        self.assertEqual(first["experiences"], second["experiences"])
        self.assertEqual(
            first["invariants_relationnels_observes"],
            second["invariants_relationnels_observes"],
        )
        self.assertGreaterEqual(first["telemetrie_execution"]["duree_secondes"], 0)
        self.assertGreater(first["telemetrie_execution"]["pic_memoire_octets_tracemalloc"], 0)

    def test_png_outputs_are_grayscale_with_expected_dimensions(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "run"
            proof = run_lab(self.config, output)
            for experiment in proof["experiences"]:
                expected = experiment["resolution"]["largeur_px"]
                for artifact in experiment["artefacts"].values():
                    payload = (output / artifact["chemin_relatif"]).read_bytes()
                    self.assertTrue(payload.startswith(PNG_SIGNATURE))
                    width, height, bit_depth, color_type = struct.unpack(
                        ">IIBB", payload[16:26]
                    )
                    self.assertEqual((expected, expected), (width, height))
                    self.assertEqual(8, bit_depth)
                    self.assertEqual(0, color_type)

    def test_proof_json_matches_returned_deterministic_sections(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "run"
            proof = run_lab(self.config, output)
            persisted = json.loads((output / "preuve.json").read_text(encoding="utf-8"))
        self.assertEqual(proof["schema"], persisted["schema"])
        self.assertEqual(proof["protocole"], persisted["protocole"])
        self.assertEqual(proof["experiences"], persisted["experiences"])

    def test_simplified_global_ssim_identity_and_change(self) -> None:
        reference = [96] * 16
        changed = reference.copy()
        changed[5] += 1
        self.assertAlmostEqual(1.0, simplified_global_ssim(reference, reference))
        self.assertLess(simplified_global_ssim(reference, changed), 1.0)

    def test_non_empty_output_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "run"
            output.mkdir()
            (output / "preuve_humaine.txt").write_text("à préserver", encoding="utf-8")
            with self.assertRaises(FileExistsError):
                run_lab(self.config, output)
            self.assertEqual(
                "à préserver",
                (output / "preuve_humaine.txt").read_text(encoding="utf-8"),
            )


if __name__ == "__main__":
    unittest.main()
