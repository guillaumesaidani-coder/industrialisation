#!/usr/bin/env python3
"""Laboratoire déterministe sur la dilution des petits défauts.

Ce module n'implémente PAS PatchCore. Le score local fourni est un
« proxy pédagogique inspiré de PatchCore » fondé sur le maximum des MSE de
patches. PatchCore réel utilise notamment des embeddings deep et un coreset.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import struct
import sys
import time
import tracemalloc
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence


PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
PATCH_PROXY_NAME = "proxy pédagogique inspiré de PatchCore"


@dataclass(frozen=True)
class LabConfig:
    """Paramètres synthétiques du laboratoire, sans valeur métier implicite."""

    resolutions: tuple[int, ...] = (32, 128)
    defect_size_px: int = 2
    patch_size_px: int = 4
    background_level: int = 96
    defect_delta: int = 96

    def validate(self) -> None:
        if len(self.resolutions) < 2:
            raise ValueError("Fournir au moins deux résolutions.")
        if tuple(sorted(set(self.resolutions))) != self.resolutions:
            raise ValueError("Les résolutions doivent être uniques et croissantes.")
        if self.defect_size_px <= 0:
            raise ValueError("defect_size_px doit être strictement positif.")
        if self.patch_size_px < self.defect_size_px:
            raise ValueError("patch_size_px doit être >= defect_size_px.")
        if not 0 <= self.background_level <= 255:
            raise ValueError("background_level doit être compris entre 0 et 255.")
        if self.defect_delta <= 0:
            raise ValueError("defect_delta doit être strictement positif.")
        if self.background_level + self.defect_delta > 255:
            raise ValueError("background_level + defect_delta doit être <= 255.")
        for resolution in self.resolutions:
            if resolution < self.patch_size_px:
                raise ValueError("Chaque résolution doit être >= patch_size_px.")
            if resolution % self.patch_size_px:
                raise ValueError(
                    "Chaque résolution doit être divisible par patch_size_px."
                )


def _png_chunk(chunk_type: bytes, payload: bytes) -> bytes:
    crc = zlib.crc32(chunk_type)
    crc = zlib.crc32(payload, crc) & 0xFFFFFFFF
    return struct.pack(">I", len(payload)) + chunk_type + payload + struct.pack(">I", crc)


def write_grayscale_png(path: Path, width: int, height: int, pixels: Sequence[int]) -> None:
    """Écrit un PNG 8 bits grayscale avec filtre PNG 0, via la stdlib."""

    if width <= 0 or height <= 0 or len(pixels) != width * height:
        raise ValueError("Dimensions ou nombre de pixels invalides.")
    if any(pixel < 0 or pixel > 255 for pixel in pixels):
        raise ValueError("Un pixel PNG doit être compris entre 0 et 255.")

    scanlines = bytearray()
    for row in range(height):
        scanlines.append(0)  # filtre « None »
        start = row * width
        scanlines.extend(pixels[start : start + width])

    header = struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0)
    payload = (
        PNG_SIGNATURE
        + _png_chunk(b"IHDR", header)
        + _png_chunk(b"IDAT", zlib.compress(bytes(scanlines), level=9))
        + _png_chunk(b"IEND", b"")
    )
    path.write_bytes(payload)


def mse(reference: Sequence[int], candidate: Sequence[int]) -> float:
    if len(reference) != len(candidate) or not reference:
        raise ValueError("Les deux images doivent avoir la même taille non nulle.")
    return math.fsum((left - right) ** 2 for left, right in zip(reference, candidate)) / len(
        reference
    )


def simplified_global_ssim(reference: Sequence[int], candidate: Sequence[int]) -> float:
    """SSIM simplifiée : une seule fenêtre globale et variances population.

    Ce calcul rend visibles moyenne, variance et covariance, mais ne remplace pas
    une SSIM multi-fenêtres issue d'une bibliothèque validée.
    """

    if len(reference) != len(candidate) or not reference:
        raise ValueError("Les deux images doivent avoir la même taille non nulle.")
    count = len(reference)
    mean_reference = math.fsum(reference) / count
    mean_candidate = math.fsum(candidate) / count
    variance_reference = (
        math.fsum((value - mean_reference) ** 2 for value in reference) / count
    )
    variance_candidate = (
        math.fsum((value - mean_candidate) ** 2 for value in candidate) / count
    )
    covariance = (
        math.fsum(
            (left - mean_reference) * (right - mean_candidate)
            for left, right in zip(reference, candidate)
        )
        / count
    )
    c1 = (0.01 * 255) ** 2
    c2 = (0.03 * 255) ** 2
    numerator = (2 * mean_reference * mean_candidate + c1) * (2 * covariance + c2)
    denominator = (
        mean_reference**2 + mean_candidate**2 + c1
    ) * (variance_reference + variance_candidate + c2)
    return numerator / denominator


def patch_mse_proxy(
    reference: Sequence[int], candidate: Sequence[int], width: int, patch_size: int
) -> dict[str, object]:
    """Calcule le proxy pédagogique inspiré de PatchCore, sans deep learning."""

    if len(reference) != len(candidate) or len(reference) != width * width:
        raise ValueError("Le proxy attend deux images carrées de même taille.")
    if patch_size <= 0 or width % patch_size:
        raise ValueError("La taille de patch doit diviser la largeur.")

    scores: list[tuple[float, int, int]] = []
    for top in range(0, width, patch_size):
        for left in range(0, width, patch_size):
            squared_errors: list[int] = []
            for row in range(top, top + patch_size):
                offset = row * width
                for column in range(left, left + patch_size):
                    index = offset + column
                    squared_errors.append((reference[index] - candidate[index]) ** 2)
            score = math.fsum(squared_errors) / len(squared_errors)
            scores.append((score, left, top))

    maximum, left, top = max(scores)
    return {
        "nom": PATCH_PROXY_NAME,
        "definition": "maximum des MSE de patches non chevauchants",
        "taille_patch_px": patch_size,
        "nombre_patches": len(scores),
        "score_local_max_mse": maximum,
        "score_moyen_patches_mse": math.fsum(score for score, _, _ in scores)
        / len(scores),
        "patch_max": {"x": left, "y": top},
    }


def synthetic_pair(resolution: int, config: LabConfig) -> tuple[list[int], list[int]]:
    """Produit un fond uniforme et le même défaut de taille fixe en pixels."""

    reference = [config.background_level] * (resolution * resolution)
    candidate = reference.copy()

    # Le défaut tient dans un seul patch, au même décalage local quelle que soit
    # la résolution. Son nombre de pixels reste fixe : c'est le contrôle étudié.
    central_patch = (resolution // 2 // config.patch_size_px) * config.patch_size_px
    offset = (config.patch_size_px - config.defect_size_px) // 2
    top = central_patch + offset
    left = central_patch + offset
    for row in range(top, top + config.defect_size_px):
        for column in range(left, left + config.defect_size_px):
            candidate[row * resolution + column] += config.defect_delta
    return reference, candidate


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65_536), b""):
            digest.update(block)
    return digest.hexdigest()


def _prepare_output(output_dir: Path) -> None:
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(
            f"Le dossier de sortie n'est pas vide : {output_dir}. "
            "Choisir un nouveau dossier pour préserver les preuves."
        )
    output_dir.mkdir(parents=True, exist_ok=True)


def run_lab(config: LabConfig, output_dir: Path) -> dict[str, object]:
    """Exécute le laboratoire et écrit PNG + preuve JSON."""

    config.validate()
    _prepare_output(output_dir)
    started = time.perf_counter()
    tracemalloc.start()
    experiments: list[dict[str, object]] = []

    try:
        for resolution in config.resolutions:
            reference, candidate = synthetic_pair(resolution, config)
            errors = [abs(left - right) for left, right in zip(reference, candidate)]
            experiment_dir = output_dir / f"resolution_{resolution}"
            experiment_dir.mkdir()

            paths = {
                "reference": experiment_dir / "reference.png",
                "avec_defaut": experiment_dir / "avec_defaut.png",
                "carte_erreur": experiment_dir / "carte_erreur.png",
            }
            write_grayscale_png(paths["reference"], resolution, resolution, reference)
            write_grayscale_png(paths["avec_defaut"], resolution, resolution, candidate)
            write_grayscale_png(paths["carte_erreur"], resolution, resolution, errors)

            global_mse = mse(reference, candidate)
            global_ssim = simplified_global_ssim(reference, candidate)
            patch_proxy = patch_mse_proxy(
                reference, candidate, resolution, config.patch_size_px
            )
            experiments.append(
                {
                    "resolution": {"largeur_px": resolution, "hauteur_px": resolution},
                    "defaut": {
                        "largeur_px": config.defect_size_px,
                        "hauteur_px": config.defect_size_px,
                        "nombre_pixels": config.defect_size_px**2,
                        "delta_niveau_gris": config.defect_delta,
                    },
                    "metriques_globales": {
                        "mse": global_mse,
                        "ssim_globale_simplifiee": global_ssim,
                    },
                    "score_local": patch_proxy,
                    "carte_erreur": {
                        "definition": "différence absolue pixel par pixel, sans seuillage",
                        "erreur_max": max(errors),
                        "pixels_non_nuls": sum(error > 0 for error in errors),
                    },
                    "artefacts": {
                        label: {
                            "chemin_relatif": path.relative_to(output_dir).as_posix(),
                            "sha256": _sha256(path),
                        }
                        for label, path in paths.items()
                    },
                }
            )
        _, peak_memory = tracemalloc.get_traced_memory()
    finally:
        tracemalloc.stop()

    duration = time.perf_counter() - started
    mse_values = [item["metriques_globales"]["mse"] for item in experiments]  # type: ignore[index]
    ssim_values = [
        item["metriques_globales"]["ssim_globale_simplifiee"]  # type: ignore[index]
        for item in experiments
    ]
    proof: dict[str, object] = {
        "schema": "vision-metrics-lab-proof-v1",
        "python": {
            "version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "contrat": "Python 3.13",
            "stdlib_uniquement": True,
        },
        "protocole": {
            "nature": "expérience synthétique contrôlée",
            "variable": "résolution du canevas",
            "controle": "défaut de taille et contraste fixes en pixels",
            "parametres": {
                "resolutions": list(config.resolutions),
                "defect_size_px": config.defect_size_px,
                "patch_size_px": config.patch_size_px,
                "background_level": config.background_level,
                "defect_delta": config.defect_delta,
            },
        },
        "limites": {
            "ssim": (
                "SSIM globale explicitement simplifiée : une seule fenêtre sur l'image "
                "complète, variances population ; ne remplace pas une implémentation validée."
            ),
            "patchcore": (
                f"{PATCH_PROXY_NAME} seulement. PatchCore réel utilise des embeddings deep "
                "et un coreset ; toute comparaison doit reprendre le même protocole."
            ),
            "interpretation": (
                "Les tailles et mesures sont celles de cette expérience synthétique, "
                "pas des seuils ni des performances métier."
            ),
        },
        "experiences": experiments,
        "invariants_relationnels_observes": {
            "mse_globale_diminue_quand_le_canevas_grandit": all(
                left > right for left, right in zip(mse_values, mse_values[1:])
            ),
            "ssim_globale_simplifiee_se_rapproche_de_1": all(
                left < right for left, right in zip(ssim_values, ssim_values[1:])
            ),
            "score_local_superieur_a_mse_globale": all(
                item["score_local"]["score_local_max_mse"]  # type: ignore[index]
                > item["metriques_globales"]["mse"]  # type: ignore[index]
                for item in experiments
            ),
        },
        "telemetrie_execution": {
            "portee": "génération et écriture des PNG, calcul des métriques",
            "duree_secondes": duration,
            "pic_memoire_octets_tracemalloc": peak_memory,
            "regle": "mesures observées sur ce run, sans seuil ni extrapolation de coût",
        },
    }
    proof_path = output_dir / "preuve.json"
    proof_path.write_text(
        json.dumps(proof, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return proof


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Mesure la dilution d'un petit défaut avec MSE, SSIM globale simplifiée, "
            "carte d'erreur et proxy pédagogique inspiré de PatchCore."
        )
    )
    parser.add_argument("--output", type=Path, required=True, help="Nouveau dossier de preuve.")
    parser.add_argument(
        "--resolutions",
        type=int,
        nargs="+",
        default=[32, 128],
        help="Résolutions carrées croissantes (défaut : 32 128).",
    )
    parser.add_argument("--defect-size-px", type=int, default=2)
    parser.add_argument("--patch-size-px", type=int, default=4)
    parser.add_argument("--background-level", type=int, default=96)
    parser.add_argument("--defect-delta", type=int, default=96)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    if sys.version_info[:2] != (3, 13):
        print(
            f"ERREUR: Python 3.13 requis, version active: {sys.version.split()[0]}",
            file=sys.stderr,
        )
        return 2
    args = _parser().parse_args(argv)
    config = LabConfig(
        resolutions=tuple(args.resolutions),
        defect_size_px=args.defect_size_px,
        patch_size_px=args.patch_size_px,
        background_level=args.background_level,
        defect_delta=args.defect_delta,
    )
    try:
        proof = run_lab(config, args.output.resolve())
    except (FileExistsError, OSError, ValueError) as error:
        print(f"ERREUR: {error}", file=sys.stderr)
        return 2

    print(f"PREUVE={args.output.resolve() / 'preuve.json'}")
    for experiment in proof["experiences"]:  # type: ignore[assignment]
        resolution = experiment["resolution"]["largeur_px"]
        metrics = experiment["metriques_globales"]
        local = experiment["score_local"]["score_local_max_mse"]
        print(
            f"resolution={resolution} mse={metrics['mse']:.12g} "
            f"ssim_globale_simplifiee={metrics['ssim_globale_simplifiee']:.12g} "
            f"proxy_local_max_mse={local:.12g}"
        )
    telemetry = proof["telemetrie_execution"]  # type: ignore[assignment]
    print(
        f"duree_secondes={telemetry['duree_secondes']:.9f} "
        f"pic_memoire_octets={telemetry['pic_memoire_octets_tracemalloc']}"
    )
    print("RESULTAT=PASS (invariants relationnels dans preuve.json)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
