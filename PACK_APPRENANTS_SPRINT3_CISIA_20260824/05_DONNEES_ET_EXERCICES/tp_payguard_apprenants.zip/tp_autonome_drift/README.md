# TP autonome — Data drift & métriques : l'affaire PayGuard

TP d'application du **module 31 CISIA** (*Data drift & métriques de dérive — concepts*, S3-M09, US3.5),
**indépendant du fil rouge InduSense** : surveillance d'un modèle anti-fraude de paiement en production.
Données 100 % synthétiques (générateur seedé fourni côté formateur) — aucune donnée réelle, aucun téléchargement.

- **Apprenants** → suivez **`TP_apprenant_payguard_drift.md`** (tout y est, installation comprise).
- **Formateur** → **`formateur/CORRIGE_formateur.md`** (conducteur, chiffres attendus mesurés, solutions,
  réponses Q1-Q18, grille). ⚠️ **Distribuer le dossier SANS `formateur/`.**

## Installation (résumé — détails dans le TP, étape 0)

Prérequis de la session : **Python 3.13** (fichier `.python-version`). Voie recommandée CISIA : **uv**.

Sous Windows, décompresser dans un chemin court, par exemple
`%USERPROFILE%\CISIA\S3\tp_autonome_drift`. Un chemin très profond peut empêcher la matérialisation d'une
extension compilée de scikit-learn malgré un message de sync réussi. Dans ce cas, repartir d'une
décompression neuve dans ce chemin court et rejouer `uv sync --frozen --extra dev` — ne pas muter le lock.

| | Windows (PowerShell) | macOS (Terminal) |
|---|---|---|
| Installer uv (si absent) | `powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 \| iex"` | `curl -LsSf https://astral.sh/uv/install.sh \| sh` (ou `brew install uv`) |
| Environnement | `uv sync --frozen --extra dev` | `uv sync --frozen --extra dev` |
| Vérification | `uv run python -c "import sklearn; print('OK')"` | idem |
| Repli sans uv | `py -3 -m venv .venv` · `.venv\Scripts\Activate.ps1` · `pip install -r requirements.txt` | `python3 -m venv .venv` · `source .venv/bin/activate` · `pip install -r requirements.txt` |

Sous Windows, poser une fois `$env:PYTHONUTF8 = "1"` dans le terminal du TP avant les scripts : leurs
messages pédagogiques contiennent des symboles Unicode que certaines consoles historiques ne savent pas afficher.

Le premier `uv sync --frozen --extra dev` crée `.venv/` à partir de `uv.lock` **sans recalculer le verrou** et installe aussi pytest (versions bornées dans `pyproject.toml` :
numpy, pandas, scipy, scikit-learn, matplotlib, joblib ; pytest via `--extra dev` ;
Evidently 0.7.x en option via `--extra evidently` pour le bonus — même famille de version que le lock InduSense).

## Structure

```
tp_autonome_drift/
├── README.md                        ← ce fichier
├── TP_apprenant_payguard_drift.md   ← énoncé pas à pas + questions (SANS réponses)
├── pyproject.toml / requirements.txt
├── data/
│   ├── reference.csv                ← 20 000 transactions labellisées (entraînement)
│   ├── courant_semaine{1,2,3}.csv   ← 3 semaines de production, SANS labels
│   └── labels/                      ← labels « arrivés en retard » (étape 6 uniquement)
├── scripts/
│   ├── train_model.py               💻 fourni — baseline Sprint 2 + seuil gelé par le coût
│   ├── drift_lab.py                 🧑‍🎓 starter à compléter — PSI, KS, table de dérive
│   ├── evaluate_semaine.py          🧑‍🎓 starter à compléter — métriques métier au seuil gelé
│   └── bonus_evidently.py           💻 fourni — bonus facultatif Evidently
├── tests/test_drift.py              💻 definition of done : 12 tests (8 unitaires + 4 intégration)
├── models/ · reports/               ← remplis par les scripts (vides au départ)
├── .github/workflows/tests.yml     💻 CI : uv + pytest (verte sur ce repo, rouge sur un repo cassé/non fini)
└── formateur/                       ⚠️ présent seulement dans la source maître, absent du zip apprenant
    ├── CORRIGE_formateur.md         ← conducteur + chiffres mesurés + réponses complètes
    ├── qcm_drift_module31.md        ← QCM de fin de séance (10 questions corrigées)
    ├── make_dataset.py              ← générateur seedé (révèle la nature des 3 semaines)
    ├── solution/                    ← drift_lab.py et evaluate_semaine.py complétés
    └── starters/                    ← versions « à trous » de référence (pour restaurer/distribuer)
```

## Parcours en 30 secondes

```bash
uv run python scripts/train_model.py            # 1. geler modèle + seuil (fourni)
# compléter scripts/drift_lab.py, puis :
uv run python -m pytest -k "psi or ks or verdict or table"  # 2. 8 tests unitaires verts
uv run python scripts/drift_lab.py --semaine 1    # 3-5. auditer les 3 semaines (sans labels)
# compléter scripts/evaluate_semaine.py, puis :
uv run python scripts/evaluate_semaine.py --semaine 1   # 6. les labels arrivent...
uv run python -m pytest                          # fin d'étape 6 — definition of done : 12 verts
# étape 7 : rédiger reports/drift_spec_payguard.md (gabarit dans le TP)
```

Vérification express poste formateur : `formateur/CORRIGE_formateur.md` §3
(copier les solutions → dérouler → `pytest` 12 verts, ~5 min).

## Observabilité

L'observabilité active est traitée en **M33-M34 sur InduSense**, avec une dépendance scellée et la stack
du repo fil rouge. Les anciens fichiers `observabilite/` et `scripts/export_metrics.py` sont conservés
uniquement dans la réserve formateur pour provenance ; ils ne font pas partie du parcours apprenant ni
du zip distribué, et aucune commande `--extra obs` ne doit être lancée.

## Intégration continue

`.github/workflows/tests.yml` (m24) : à chaque push, uv + entraînement + pytest. Sur CE repo
(où `formateur/solution` existe), les solutions sont copiées avant les tests → **CI verte =
solutions valides**. Sur un fork apprenant (sans `formateur/`), la CI reflète l'état réel du code —
rouge tant que le TP n'est pas terminé.

⚠️ Les fichiers `scripts/drift_lab.py` et `scripts/evaluate_semaine.py` versionnés ici doivent
rester les **starters** (copies de référence dans `formateur/starters/`). Si vous les complétez
pour tester, restaurez-les avant de committer : `git restore scripts/` ou
`cp formateur/starters/*.py scripts/`.

## Liens parcours

Concepts : module **31** (PSI, KS, covariate vs concept drift, drift spec, KPI technique vs métier).
Révisions embarquées : Sprint 2 **m11** (accuracy vs rappel, PR-AUC, coût FN≫FP), **m21** (ROC/PR,
seuil par coût gelé sur la validation), **m22** (model card). Débouche sur le module **32**
(automatisation : rapport, alerting, anti-bruit) — la drift spec produite ici s'y branche telle quelle.
